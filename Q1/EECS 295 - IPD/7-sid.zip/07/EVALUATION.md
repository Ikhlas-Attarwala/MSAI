# IPD Homework 7: Hexapawn
Team: /ikhlas /siddhartha

## Test Cases

  - TEST_CASE("Testing the constructor for Model") (line 6, model_test.cpp) checks whether the constructor builds
  the board_ to have Player 1's pawns in the first row, Player 2's pawns to be in the bottom row
  and sets turn_ to player 1 and winner to neither. 
  
  - TEST_CASE("Testing edge cases for constructor for Mode") (line 39, model_test.cpp) checks whether an error is thrown 
  if the 
  user enters values which are below 3 (thus leading to a nonsensical game where Player 1) would always win
  and greater than 8 (where the entirety of the board would not be visible on programmer's screen).
  
  - TEST_CASE("Testing rotate()") (line 45, model_test.cpp) tests the rotate() function, to ensure that the board 
  rotates 180 degrees.
  
  - TEST_CASE("Testing Other Player(): Pass case") and TEST_CASE("Testing Other Player(): Fail case") (lines 68 and 74, 
  model_test.cpp) test whether the function returns the inactive player and returns a logical error if turn_ == Player::
  neither
  
  - TEST_CASE("Testing get_cell()") (line 79, model_test.cpp) performs trivial tests on the get_cell() function and checks whether it
  appropriately returns Player::first, Player::second and Player::neither.
  
  - TEST_CASE("Testing 3x3 game") (line 87, model_test.cpp) tests the flow of the game, testing whether players are 
  unable to select empty squares, his/her opponent's pawns and can select his own pawns. Post selection, the test checks
   that the player can de-select the currently selected pawn, or can move the pawn 1 space (vertically 1 row below or if there's an opponent pawn 1 square diagonally away, can capture that pawn).
   The test also checks that board rotates on each turn and the game ends and a winner is confirmed on if a pawn reaches the opposite side of teh board. 
  
  - TEST_CASE("3x3 game - Game detects no legal moves, previous player wins.") (line 172, model_test.cpp) performs test 
  to see what occurs in the case of a stalemate and confirms that the last player who played a move is considered a
   winner. 
   
    
    
## What Surprised Us
 - The row `board_[0]` is displayed at the bottom of the screen and row `board[m_-1]` is displayed at the top.
 Thus the board is upside down compared to what we expected and the game is played top to bottom instead of bottom to top. 
 
 - How complex the usage of text sprites is. 
