#include <iostream>
#include <catch.h>
#include "huff.h"

// using namespace huffman;

TEST_CASE("Testing 'convert' function to see if it stores variables correctly")
{
    // open terminal and nagivate to homework directory, then do:
    //          cd cmake-build-debug
    //			./myencode ../test-files/small.txt out.tmp

    //
    CHECK(std::str == "aabc");
}

*node new_node(a, 5)
{
    *node update = new node();
    update->char_ = a;
    update->freq_ = 5;
}

*node new_node(b, 4)
{
    *node update = new node();
    update->char_ = b;
    update->freq_ = 4;
}

*node new_node(c, 3, new_node(a, 5), new_node(b, 4))
{
    *node update = new node();
    update->char_ = b;
    update->freq_ = 3;
    update->left_ = new_node(a, 5);
    update->right_ = new_node(b, 4);
}

TEST_CASE("Testing 'count_and_assign' function to see if it creates new nodes")
{
    CHECK(string "a") == new_node(char a, int 1);
    CHECK(string "0") == new_node(char "0", int 1);
}

TEST_CASE("Testing 'arrange_nodes' function to see which node goes to the left and right")
{
    return 0; //did not do this function yet in .cpp
}

TEST_CASE("Testing the 'compare' function")
{
    CHECK(bool new_node(new_node(a, 5), new_node(b, 4))) == T;
    CHECK(bool new_node(new_node(b, 4), new_node(a, 5))) == F;
}

TEST_CASE("Testing 'combine2' function")
{
    CHECK(combine2(new_node(a, 5), new_node(b, 4))) ==
    (new_node (nullptr, 9, new_node(a, 5), new_node(b, 4)))
}

TEST_CASE("Testing 'remove_node' function")
{
    return 0; //did not do this function yet in .cpp
}

TEST_CASE("Testing 'swap_node' function")
{
    test_a = new_node(a, 5);
    test_b = new_node(b, 5);
    CHECK(*b == test_b);
    (swap_node(test_a, test_b));
    CHECK(*b == test_a);
}

TEST_CASE("Testing 'assign_binaries' function")
{
    return 0; //did not do this function yet in .cpp
}



