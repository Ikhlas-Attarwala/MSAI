#include "common.h"
#include "bit_io.h"

int main(int argc, const char* argv[])
{
    // Take serialized output stream and convert it back into an input stream
    // Input: bostream
    // Output: bistream

    // Take input stream from huff and convert it back into the huffman tree we created
    // Input: bistream
    // Output: Huffman tree from huff

    // Take the variable


    return 0;
}
