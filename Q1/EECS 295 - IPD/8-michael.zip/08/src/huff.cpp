#include "huff.h"
#include "bit_io.h"
#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

// A node exists of this format
struct node
{
    char char_;
    int freq_;
    node *left;
    node *right;
}

// Create a new_node that is a node (shown abaove)
        *node new_node(char c, int f, node* l, node* r)
{
    *node update = new node();
    update->char_ = c;
    update->freq_ = f;
    update->*left = l;
    update->*right = r;
}

// Provided an input file, reads the file and stores characters in a string
// haven't used ipd::bostream&out yet
void convert(istream& in, ipd::bostream& out)
{
    char c;
    string str;

    while (in.read(&c, 1))
    {
        str.append(c);
    }
}

// Counts instances of each character in a string, assigns it to frequency,
// then assigns both to a node
*node count_and_assign(string str)
{
    for (int i=0, i<256, i++)
    {
        //counts frequency per character
        //don't know how to find ASCII, so I guessed it was char(#)
        int frequency = count(str.begin(), str.end(), char(i));
        //assign frequency to that character somehow
        new_node(char char(i), int frequency);
    }
}

// Take all created new_nodes and sort them by increasing frequency
struct arrange_nodes(new_node* char c, int f, node* l, node* r)
// should actually be list of new_nodes not just one new_node
{
return 0;
//?? UNFINISHED: Need to place nodes with smaller frequencies first, but under
//   what type? Also how do I innput this organization into ...
}

// Helper function, requires the need to find the smaller of two heaps.
struct compare
{
    bool node (*left, *right)
    {
        return *left->freq_ > *right->freq_;
    }
}

// Combine nodes (sum 2 smallest and repeat)
        *node combine2(*node a, *node b)
{
struct node
{
    char c = nullptr;
    int f = (a.freq_ + b.freq_); //would actually be the sum of both new_nodes' frequencies
    node *l = new_node* a;
    node *r = new_node* b;
}
}

// Helper function for arrange_nodes: Remove 1 node
void remove_node(*node a, arrange_nodes)
{
return 0;
// not sure how to do this...
}

// Helper function for arrange_nodes: Swap other node and combine2
void swap_node(*node a, *node b)
{
struct *node x = *a;
*a = *b;
*b = x;
}

// Assuming tree is arranged properly, we want to start assigning 0s and 1s to each leaf
// Traverse leaf and assign 0s and 1s to each leaf (going left or right respectively)
void assign_binaries(*node)
{
    return 0;
    // How do I assign each ASCII a set of binaries?
    // Once I say it goes down left, how I determine I've reached a leaf (character)?
}

// Need to store a key and value together (ASCII with its binaries based on tree)

// Take str from function convert and swap out characters with the value the huffman tree
// provided for that specific character.

// SERIALIZATION

// Take tree, and traverse down, left priority. If you reach a branch, assign 1 to a
// variable and continue. If you reach a leaf, assign 0 + the 8-bit code for that character,
// and repeat toward the right. Turn this into bostream. Add bistream into puff.cpp.

// In puff, once you have the bistream, reverse the serialization, and traverse the
// stream until you reach a 0, and place a node there along with the 8-bit character following.
// Then go back to 1 and search the right node if possible, else go back up.

// Take the string with stored binaries and re-implement through the tree we just de-serialized.
// Output should be characters, and that of the original file.


