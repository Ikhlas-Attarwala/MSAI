#pragma once
#include "bit_io.h"
#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

struct node;
// A node exists of this format

*node new_node(char c, int f, node* l, node* r);
// Create a new_node that is a node (shown abaove)

void convert(istream& in, ipd::bostream& out);
// Provided an input file, reads the file and stores characters in a string
// haven't used ipd::bostream&out yet

*node count_and_assign(string str);
// Counts instances of each character in a string, assigns it to frequency,
// then assigns both to a node

struct arrange_nodes(new_node* char c, int f, node* l, node* r);
// Take all created new_nodes and sort them by increasing frequency
// (should actually be list of new_nodes not just one new_node)

struct compare;
// Helper function, requires the need to find the smaller of two heaps.

*node combine2(*node a, *node b);
// Sum 2 lowest frequencies and create a new node with that frequency and no character value.
//   It's left child should be the first node, and right child should be the second node.

void remove_node(*node a, arrange_nodes);
// Helper function for arrange_nodes: Remove 1 node

void swap_node(*node a, *node b);
// Helper function for arrange_nodes: Swap other node and combine2

void assign_binaries(*node);
// Assuming tree is arranged properly, we want to start assigning 0s and 1s to each leaf
// Traverse leaf and assign 0s and 1s to each leaf (going left or right respectively)




void encode(std::istream& in, ipd::bostream& out);
// Encodes the ASCII input stream from `in` onto `out`.

void decode(ipd::bistream& in, std::ostream& out);
// Decodes the 7-bit-packed input stream from `in` onto `out`.

