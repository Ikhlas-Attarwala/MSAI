#include "mst.h"
#include <catch.h>

using namespace ipd;

TEST_CASE("sortWUGraph")
{
    WU_graph g(7);
    g.add_edge(1, 2, 7);
    g.add_edge(1, 3, 9);
    g.add_edge(1, 6, 14);
    g.add_edge(2, 3, 10);
    g.add_edge(2, 4, 15);
    g.add_edge(3, 4, 11);
    g.add_edge(3, 6, 2);
    g.add_edge(4, 5, 6);
    g.add_edge(5, 6, 9);

    CHECK(7 == g.size());
    CHECK(6 == g.get_edge(4, 5));
    CHECK(9 == g.get_edge(1, 3));

    mst mt(7);

    WU_graph kruskal(const WU_graph& g);

    CHECK(2 == mt.gra_obj[0][2]);
    CHECK(2 == mt.gra_obj[1][2]);
    CHECK(6 == mt.gra_obj[2][2]);
    CHECK(6 == mt.gra_obj[3][2]);

    CHECK(2 == mt.mst_path[0][2]);
    CHECK(6 == mt.mst_path[1][2]);
    CHECK(7 == mt.mst_path[7][2]);
    CHECK(9 == mt.mst_path[9][2]);
    CHECK(9 == mt.mst_path[9][2]);
    
}