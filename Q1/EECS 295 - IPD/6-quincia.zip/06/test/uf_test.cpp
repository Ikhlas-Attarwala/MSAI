#include "Union_find.h"
#include "WU_graph.h"
#include <catch.h>
#include <vector>

using namespace ipd;

TEST_CASE("union_find")
{
    Union_find u(7);

    CHECK(7 == u.size());

    CHECK(0 == u.find(0));
    CHECK(6 == u.find(6));

    u.do_union(0, 2);
    u.do_union(0, 3);
    u.do_union(3, 4);

    CHECK(4 == u.find(0));
    CHECK(4 == u.find(2));
    CHECK(4 == u.find(3));
}

