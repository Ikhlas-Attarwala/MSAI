#include "WU_graph.h"
#include "Union_find.h"
#include <algorithm>

#include <cassert>

using namespace std;

namespace ipd
{

    // Creates a new union-find of `n` objects. Assign root of each vertex as itself.
    Union_find::Union_find(size_t n)
    {
        //root = new int[n];
        for (size_t i = 0; i < n; i++)
        {
            root.emplace_back(i);
        }
    }

    size_t Union_find::size() const
    {
        return root.size();
    }

    // Finds the set representative for a given object.
    size_t Union_find::find(size_t x)
    {
        if (root[x] == x) { return x;}
        root[x] = find(root[x]);
        return root[x];
    }

    // Unions the sets specified by the two given objects.
    void Union_find::do_union(size_t x, size_t y)
    {
        size_t px = find(x);
        size_t py = find(y);
        if (px != py) {root[px] = py;}
    }

}