#pragma once

#include "WU_graph.h"

namespace ipd
{

struct mst {

    // NO_WEIGHT == +inf.0, representing the absence of a weight:
    static double const NO_WEIGHT;

    // Vertices are natural numbers from 0 to |V| - 1:
    using vertex    = size_t;

    // Weights are doubles:
    using weight    = double;

    // graph object
    std::vector<std::vector<double>> gra_obj;

    // mst path
    std::vector<std::vector<double>> mst_path;

    // Creates a new mst graph of `n` objects.
    explicit mst(size_t n);

    // Read one weight
    weight read_weight(size_t n, vertex u, vertex v, weight w);

    // Sort ascending of objects by weight
    void make_sort(int col);

    // Computes a minimum spanning forest by Kruskal's algorithm.
    WU_graph kruskal(const WU_graph&);

};









}
