#include "mst.h"
#include "Union_find.h"

namespace ipd
{
    const double mst::NO_WEIGHT = std::numeric_limits<double>::infinity();

    // Creates a new union-find of `n` objects. Assign root of each vertex as itself.
    mst::mst(size_t n)
    {
        for (size_t row = 0; row < n*n; row++)  // number of rows: n*n, columns: 3
            gra_obj.emplace_back(3, mst::NO_WEIGHT);

        for (size_t row = 0; row < n; row++)  // number of rows: n*n, columns: 3
            mst_path.emplace_back(3, mst::NO_WEIGHT);
    }

    WU_graph::weight mst::read_weight(size_t n, vertex u, vertex v, weight w)
    {
        gra_obj[n*u+v][0] = u;
        gra_obj[n*u+v][1] = v;
        gra_obj[n*u+v][2] = w;
    }

    void mst::make_sort(int col)
    {
        std::sort(gra_obj.begin(),
                  gra_obj.end(),
                  [col](const std::vector<double>& lhs, const std::vector<double>& rhs) {
                      return lhs[col] < rhs[col];
                  });
    }

    WU_graph kruskal(const WU_graph& graph)
    {
        size_t n = graph.size();
        std::vector<size_t> rank;
        mst mt(n);
        Union_find uf(n);

        // read a WU_graph
        for (size_t i=0; i< n; i++)
        {
            for (size_t j=0; j < n; j++)
            {
                mt.read_weight(n, i, j, graph.get_edge(i, j));
            }
        }

        // sort graph object according to weight
        mt.make_sort(2);

        // union-find
        for (size_t i=0; i<n; i++)
        {
            if (uf.find(mt.gra_obj[i][0]) != uf.find(mt.gra_obj[i][1]))
            {
                uf.do_union(mt.gra_obj[i][0], mt.gra_obj[i][1]);
                // save vertex and weight
                mt.mst_path[i][0] = mt.gra_obj[i][0];
                mt.mst_path[i][1] = mt.gra_obj[i][1];
                mt.mst_path[i][2] = mt.gra_obj[i][2];
            }

            if (mt.mst_path.size() == n-1) { break; }
        }
    }

}
