#pragma once

#include <cstddef>
#include <vector>
#include "WU_graph.h"

namespace ipd
{

// A union-find object representing disjoint sets of `size()` objects.
class Union_find
{
public:

    // Creates a new union-find of `n` objects.
    explicit Union_find(size_t n);

    // Returns the number of objects in the union-find.
    size_t size() const;

    // Unions the sets specified by the two given objects i, j.
    void do_union(size_t i, size_t j);

    // Finds the set representative for a given object n.
    size_t find(size_t i);

private:

    // Create root of each object. The initial value is the object it self.
    std::vector <size_t> root;

};

}
