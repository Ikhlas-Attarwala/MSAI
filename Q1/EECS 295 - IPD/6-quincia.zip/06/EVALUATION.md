1. How you tested your programs to ensure correctness.

Test Union_find first before working on mst. Union_find is an independent program. The function of Union_find is to
find which groups of any two objects and group them in case if they are different.

mst should read a WU_graph first and sort the objects according to weight. Test this function before implement Union_find.



2. Anything that surprised you while doing this assignment.
(1) A Wu_graph is a n-by-n 2D-vector (n is the size of vertexes in the graph). After sorting, we get n*n-by-3 2D-vector. The columns are filled with vertex indexes
(u ,v) and weight.
(2) A vector is used to save unified vertexes and weight. The mst loop is terminated when observing the size of vector
researches n-1, which means every vertex is searched.